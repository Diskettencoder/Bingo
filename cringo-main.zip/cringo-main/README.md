# cringo
A Bullshit Bingo for Scientific Conferences
